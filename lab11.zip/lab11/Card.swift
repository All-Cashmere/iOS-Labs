//
//  Card.swift
//  lab11
//
//  Created by Dakyung Lee on 2019-04-05.
//  Copyright © 2019 Dakyung Lee. All rights reserved.
//

import Foundation
class Card{
    
    var rank:Int
    var suit:String
    init(rank:Int, suit:String){
        self.rank = rank
        self.suit = suit
    }
}
