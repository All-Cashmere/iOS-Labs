//
//  CardView.swift
//  lab11
//
//  Created by Dakyung Lee on 2019-04-05.
//  Copyright © 2019 Dakyung Lee. All rights reserved.
//

import UIKit

@IBDesignable
class CardView: UIView {
    
    @IBInspectable
    var rank:Int = 1{
        didSet{
            //draw func
            setNeedsDisplay();
            //layout func
            setNeedsLayout()
    }
    }
    @IBInspectable
    var suit:String = "X"{
        didSet{
            //draw func
            setNeedsDisplay()
            //layout func
            setNeedsLayout()
        }
    }
    @IBInspectable
    var radius:CGFloat = 10.0
    @IBInspectable
    var isFaceUp:Bool = true{
        didSet{
            //draw func
            setNeedsDisplay()
            //layout func
            setNeedsLayout()
        }
    }
    //lazy - wait until someone asks for the type
    lazy var topLabel:UILabel = createLabel()
    lazy var bottomLabel:UILabel = createLabel()
    
    @IBInspectable
    var color:UIColor = #colorLiteral(red: 1, green: 0.6908749938, blue: 0.5666965246, alpha: 1)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder:aDecoder)
        setupView()
    }
    
    private func setupView(){
        backgroundColor = self.color
        
    }
    
    private func createLabel()->UILabel{
        
        let lab = UILabel()
        lab.numberOfLines = 2
        addSubview(lab)
        lab.attributedText = attributedText("\(rank)\n\(suit)", fontSize: 24.0)
        lab.frame.size = CGSize.zero
        lab.sizeToFit()
        return lab
        
        
    }
    
    private func attributedText(_ string:String, fontSize:CGFloat)->NSAttributedString{
        var font = UIFont.preferredFont(forTextStyle: .body).withSize(fontSize)
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        return NSAttributedString(string :string, attributes: [.paragraphStyle:paragraphStyle, .font:font])
    }

    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        backgroundColor = self.color
        
        let rRect = UIBezierPath(roundedRect: bounds, cornerRadius: radius)
        rRect.addClip()
        UIColor.gray.setFill()
        rRect.fill()
        
    }
 
    override func layoutSubviews() {
        topLabel.frame.origin = bounds.origin.offsetBy(dx: 10.0, dy:10.0)
        
        bottomLabel.transform = CGAffineTransform.identity.rotated(by: CGFloat.pi)
        bottomLabel.frame.origin = bounds.origin.offsetBy(dx: bounds.maxX, dy: bounds.maxY)
        .offsetBy(dx: -bottomLabel.bounds.maxX, dy:-bottomLabel.bounds.maxY)
        .offsetBy(dx: -10.0, dy: -10.0)
        
        topLabel.isHidden = !isFaceUp
        bottomLabel.isHidden = !isFaceUp
        topLabel.attributedText = attributedText("\(rank)\n\(suit)", fontSize: 24.0)
        bottomLabel.attributedText = attributedText("\(rank)\n\(suit)", fontSize: 24.0)
        
        
    }
}

extension CGPoint {
    
    func offsetBy(dx:CGFloat, dy:CGFloat)->CGPoint{
        return CGPoint(x: x+dx, y: y+dy)
    }
}
