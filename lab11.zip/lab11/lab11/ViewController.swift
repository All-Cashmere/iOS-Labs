//
//  ViewController.swift
//  lab11
//
//  Created by Dakyung Lee on 2019-04-05.
//  Copyright © 2019 Dakyung Lee. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var card: CardView!{
        didSet{let swipe = UISwipeGestureRecognizer(target: self, action: #selector(nextCard))
            swipe.direction = [.left, .right]
            card.addGestureRecognizer(swipe)
            
        }
    }
    @objc func nextCard(){
        card.rank = (card.rank+1)%10
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func tabAction(_ sender: UITapGestureRecognizer) {
        switch sender.state {
        case .ended:
            card.isFaceUp = !card.isFaceUp
        default:
            break
        }
     
        
    }
}

