//
//  ViewController.swift
//  lab9
//
//  Created by Dakyung Lee on 2019-04-05.
//  Copyright © 2019 Dakyung Lee. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    var msg: String!
    var listener: MyTableViewController!
    
    
    @IBOutlet weak var text: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        if let m = msg{
            text.text = m
        }
        else{
            text.text="empty :("
        }
        listener!.receive(msg:"Henlo fren")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

