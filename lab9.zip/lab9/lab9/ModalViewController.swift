//
//  ModalViewController.swift
//  lab9
//
//  Created by Dakyung Lee on 2019-04-05.
//  Copyright © 2019 Dakyung Lee. All rights reserved.
//

import UIKit

class ModalViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func onclose(){
        
    }
    
    @IBAction func finish(_ sender: Any) {
        dismiss(animated: true, completion: onclose)
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
